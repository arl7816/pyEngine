# pyGameTest

This repo holds the files to test games and games made using a combo of pygame and custom game engine made called pygameEngine which is still in early development.
The basic setup for how to set up a game is included but feel free to use your own setup.

Documentation on how to use the engine will come out as the engine becomes more usable.

Requires:
  Python version 3.7 or later
  and latest version of pygame
